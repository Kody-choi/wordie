/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package placeholder;

// This class is an object-oriented class designed for the FileIO class. The FileIO class will be using Word objects to save the dictionary file and retrieve key data efficiently.
public class Word {
    // Instance variables for each Word object are index, name (actual   
    // word), type (e.g. noun, adjective, adverb, verb), definition, and 
    // example (for words in dictionary which don’t have an example, we 
    // save “None”)
    private String index;
    private String name;
    private String type;
    private String definition;
    private String example;
   
    // Below is the constructor for initializing each instance variable
    public Word(String index, String name, String type, String definition, String example) {
        this.index = index;
        this.name = name;
        this.type = type;
        this.definition = definition;
        this.example = example;
    }
   
    // Getters for each instance variable below
    public String getIndex() {
        return index;
    }
   
    public String getName() {
        return name;
    }
   
    public String getType() {
        return type;
    }
   
    public String getDefinition() {
        return definition;
    }
   
    public String getExample() {
        return example;
    }
  
    // Setters for each instance variable below
    public void setIndex(String index) {
        this.index = index;
    }
   
    public void setName(String name) {
        this.name = name;
    }
   
    public void setType(String type) {
        this.type = type;
    }
   
    public void setDefinition(String definition) {
        this.definition = definition;
    }
   
    public void setExample(String example) {
        this.example = example;
    }
   
    // A toString method which returns a String containing all the
    // instance variables appending using a comma
    public String toString() {
        String returner = this.index + ", " + this.name + ", " + this.type + ", " + this.definition + ", " + this.example;
        return returner;  
    }
}

