/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package placeholder;

import java.io.*;
import java.util.ArrayList;
import java.util.Random;


public class FileIO {
    public static void readFile(ArrayList<Word> wordList){
        //int counter = 0;
        try{
            BufferedReader inFile = new BufferedReader(new FileReader("possibleAnswers.csv"));
            String valueString = inFile.readLine();
            while(valueString != null){
                addToList(valueString, wordList);
                valueString = inFile.readLine();
                //counter = counter+1;
                /*
                if(counter == 40){
                    break;
                }
                */
            }
            inFile.close();
        }
        catch(IOException e){
            e.printStackTrace();
        }
    }
    public static void addToList(String valueString, ArrayList<Word> wordList){
        boolean wordExist = false;
        String [] parts = valueString.split("\\|");
        String definition;
        String example;
        for(Word element: wordList){
            // If the world already exists in the list
            if(parts[0].equals(element.getIndex())){
                wordExist = true;
                // Adding a new definition to the preexisting definition(s)
                definition = parts[3]+": "+parts[4];
                // "&" will be used to split up the definitions to displaying nicely in the GUI
                String modifiedDefinition = element.getDefinition()+" &"+parts[1]+". "+definition;
                element.setDefinition(modifiedDefinition);


                example = parts[5];
                String modifiedExample = element.getExample()+" &"+parts[1]+". "+example;
                element.setExample(modifiedExample);
                break;
            }
        }
        if(wordExist == false){
            parts[4] = "1. "+parts[3]+": "+parts[4];
            parts[5] = "1. "+parts[5];


            Word newWord = new Word(parts[0], parts[2], parts[3], parts[4], parts[5]);
            wordList.add(newWord);
        }
    }
    public static Word generateWord(ArrayList<Word> wordList){
        // Randomizes a word from the list
        int numOfWords = wordList.size();
        Random randomNum = new Random();
        int answer = randomNum.nextInt(numOfWords+1);
        return wordList.get(answer);
    }








/* The method below is a static method meant to implement binary search
through recursion. It takes an array list of Word objects, the target String, and 2 integers which signify the starting and ending index for the search as parameters. The method returns an integer representing whether or not the target exists in the list (each Word object’s String name is compared to the String target). */
   
public static int validateBinarySearch(ArrayList<Word> myList, String target, int begin, int end) {
        // If the beginning index is greater than the end index, this
      // means the target String doesn’t exist. Thus, we return -1.
  if (begin > end) {
            return -1;
        }
        // Finding the mid index to split the list as per search algorithm
        int mid = (begin + end) / 2;
        // Fetch the Word in the middle index of list
        Word midWord = myList.get(mid);
        // Fetch the name of the word in the middle index of list
        String value = midWord.getName();
       
        //DELETE THIS LINE BELOW. ONLY USED FOR TESTING.
        // System.out.println(value);
       
        // Conditional statement for when target matches mid value
  if (value.equals(target)) {
            return mid;
        }
        // Conditional statement for when target alphabetically appears
        // BEFORE the mid value
        else if (value.compareTo(target) > 0) {
            // Search the left half of the list using recursion
            return validateBinarySearch(myList, target, begin, mid - 1);
        }
        // Conditional statement for when target alphabetically appears
        // AFTER the mid value
        else {
            // Search the right half of the list using recursion
            return validateBinarySearch(myList, target, mid + 1, end);
        }
    }








    public static void scoreBoardMaker(String score, boolean isAppend){
        try{
            System.out.println(score);


            BufferedWriter outFile = new BufferedWriter(new FileWriter("scoreBoard.csv", isAppend));
           
            if (!isAppend){
                outFile.write("INDEX, ANSWER, # OF GUESSES, ROUND POINTS, TOTAL POINTS, \n" + score+"\n");
            } else {
                outFile.write(score+"\n");
            }
            
           
           
            System.out.println("completed");
            outFile.close();
        }
        catch(IOException e){
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        ArrayList<Word> wordList = new ArrayList<>();
        readFile(wordList);
        Word targetWord = generateWord(wordList);
        String targetWordName = targetWord.getName();
        System.out.println(targetWord);
       
        // Temporarily using the random word as the word to search for in the list
        int response = validateBinarySearch(wordList, targetWordName, 0, wordList.size() - 1);
        if (response != -1) {
            System.out.println("Word Found");
        }
        else {
            System.out.println("Not found");
        }


        scoreBoardMaker(targetWordName, false);


         //Prints out every element in the array list
        for(Word element: wordList){
            System.out.println(element.getName()+" | "+element.getDefinition()+" | "+element.getExample());
        }
       
       
    }
}