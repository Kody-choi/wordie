/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package placeholder;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;


/**
 * The <code>LetterJudge</code> class is a game where the user tries to guess a 5-letter word passed by the constructor.<p>
 * The user is given feedback on their guesses in the form of color hints:<p>
 * - Green: The letter is in the correct position in the answer word.<p>
 * - Yellow: The letter is present in the answer word but in the wrong position.<p>
 * - Grey: The letter is not present in the answer word.<p>
 * The game continues until the user correctly guesses the word or reaches the maximum number of attempts (6).<p>
 * Each instance of the <code>LetterJudge</code> class represents a single round of the game.<p>
 */
public class LetterJudge {
   
    // Static Variables
    /** Keeps track of the total number of rounds played
     * across all <code>LetterJudge</code> instances*/
    private static int roundCount = 0;


    /*
     * The total score of all rounds
     */
    private static int totalScore = 0;


    // TODO: private static ArrayList<String> validWordList
    // The object is used to check if the user input is valid.
    // Generated from the dictionary object.
    // E.g. [""]
    // TODO: Ask Annika & Valerie to get all strings (words) in the dictionary,
    // TODO: store in a static ArrayList<String>,
    // TODO: and write a setter (appending) and getter for it.
    // TODO: This is the union of possibleAnswers and validWords.
    // Object Variables
    // TODO: private Word answer;
    // The Word object chosen from the dictionary, to be used as an answer for the user to guess.
    // The object is used to retrieve definitions and examples.
    // I will use a getter method to retrieve this from FileIO Class


    private Word answerWord = FileIO.generateWord(wordList);


    private String answerTypes = answerWord.getType();


    private String answerDefinitions = answerWord.getDefinition();


    private String answerExamples = answerWord.getExample();


    /** The word to be guessed in the current round in STRING FORM */
    private String answer = NONE_STRING;


    /** The user's current guess for the round */
    private String userInput = NONE_STRING;


    /** Error messages for invalid user input in the current round, separated by "\n" */
    private ArrayList<String> errorMessages = new ArrayList<>();


    /** Array of color hints (0 = green, 1 = yellow, 2 = gray) for the user's current guess */
    private int[] letterHints = getInitializedLetterHints();


    /** List of previous guesses/attempts made by the user in the current round */
    private ArrayList<String> previousGuesses = new ArrayList<>();


    /** Number of guesses made by the user up to the PREVIOUS round */
    private int previousGuessCount = 0;


    /** Code indicating the game state for the current round
     * (0 = continue, 1 = correct guess, 2 = maximum guesses reached) */
    private int roundVerdictCode = ROUND_DEFAULT_CODE;


    /*
     * The score of this round, specified by the constant POINT_SYSTEM
     */
    private int roundScore = 0;


    // Constants
    /**
     * The wordList will store all Word instances in possibleAnswers.csv into an arrayList
     */
    private static final ArrayList<Word> wordList = getInitializedWordList();


    private static final ArrayList<Word> getInitializedWordList(){
        ArrayList<Word> output = new ArrayList<>();
        FileIO.readFile(output);
        return output;
    }
    private static final ArrayList<String> getInitializedWordListToString(){
        ArrayList<String> output = new ArrayList<>();
        for (Word currentWord : wordList){
            String currentWordName = currentWord.getName();
            output.add(currentWordName);
        }
        return output;
    }


    /**
     * The default value for <code>this.letterHints</code> int[5] array when
     * the user input has not been provided.
     */
    private static final int LETTER_HINT_DEFAULT_VALUE = -100;


    /**
     * The code returned in the <code>this.letterHints</code> int[5] array
     * when the letter is in the correct position.
     */
    private static final int LETTER_HINT_GREEN_CODE = 1;


    /**
     * The code returned in the <code>this.letterHints</code> int[5] array
     * when the letter appears but in the wrong position.
     */
    private static final int LETTER_HINT_YELLOW_CODE = 0;
   
    /**
     * The code returned in the <code>this.letterHints</code> int[5] array
     * when the letter does not appear.
     */
    private static final int LETTER_HINT_GREY_CODE = -1;


    /**
     * The placeholder used for <code>this.getRoundVerdict</code> when the user input is not provided.
     */
    private static final int ROUND_DEFAULT_CODE = -1;


    /**
     * The code used for <code>this.getRoundVerdict</code> when the round has not ended,
     * such as when the user still have more guess attempts or the input is invalid.
     */
    private static final int ROUND_IS_CONTINUE_CODE = 0;


    /**
     * The code used for <code>this.getRoundVerdict</code> when
     * the round ends by user guessing correctly.
     */
    private static final int ROUND_CORRECT_GUESS_CODE = 1;


    /**
     * The code used for <code>this.getRoundVerdict</code> when
     * the round ends by user running out of guesses.
     */
    private static final int ROUND_MAXIMUM_GUESS_REACHED_CODE = 2;
    /**
     * Maximum number of guesses allowed per round.
     */
    private static final int MAX_GUESS_COUNT = 6;


    /**
     * Error message to be displayed when the toString() method
     * is called while the round is still ongoing.
     * If the toString is called when the round has not ended,
     * some of the user's guesses will be missing.
     */
   
   
    /**
     * String representation of "None" to be used as a
     * placeholder for missing guesses.
     */
    private static final String NONE_STRING = "None";
   
    /**
     * Error message to be displayed when the user's guess does not appear in <code>"possibleAnswer.csv"</code>.
     */
    private static final String NOT_IN_LIST_ERROR_MESSAGE = "Error: Input not in list!";


    /**
     * Error message to be displayed when the user's guess has been guessed previously.
     * Will be added at the time <code>this.addErrorMessage(this.userInput)</code> is called.
     */
    private static final String ALREADY_APPEARED_ERROR_MESSAGE = "Error: the answer has been guessed previously!";
   
    /**
     * Error message to be displayed when the user's input does not have the correct length.
     */
    private static final String WRONG_LENGTH_ERROR_MESSAGE = "Error: the input does not have the right length!";
   
    /**
     * Error message to be displayed when the user's input contains non-alphabetic characters.
     */
    private static final String NONLETTER_ERROR_MESSAGE = "Error: the input must be made of alphabets!";
   
    /**
     * Message format to be used when the user guesses the word correctly, displaying the number of tries and the maximum number of guesses allowed.
     */
    private static final String WORD_GUESSED_MESSAGE_FORMAT = "Congratulations! It takes %d out of %d tries.";
   
    /**
     * Message format to be used when the user runs out of guesses, displaying the correct answer.
     */
    private static final String MAX_GUESSES_REACHED_MESSAGE_FORMAT = "Unfortunately you did not get this one. The answer is %s.";
   
    /**
     * Delimiter to be used when joining strings in the toString() method.
     */
    private static final String TO_STRING_DELIMITER = ",";


    private static final HashMap<Integer, Integer> POINT_SYSTEM = new HashMap<>(Map.of(
        1, 100,
        2, 50,
        3, 40,
        4, 30,
        5, 20,
        6, 10,
        -1, 0
    ));


    // TODO: Rewrite constructor when Word Class is done.
    // Constructor
    /**
     * <p>Constructor for the <code>LetterJudge</code> class.</p>
     *
     * <p>This constructor initializes a new instance of the <code>LetterJudge</code> class
     * with the provided answer word. It performs the following tasks:</p>
     *
     * <ol>
     *     <li>Increments the static <code>roundCount</code> variable to keep
     *     track of the number of rounds played.</li>
     *     <li>Sets the <code>userInput</code> instance variable to the string
     *     literal <code>"None"</code> initially.</li>
     *     <li>Converts the provided <code>answer</code> to ALL CAPS and assigns
     *     it to the <code>answer</code> instance variable.</li>
     *     <li>Initializes the <code>guessCount</code> instance variable to <code>0</code>.</li>
     *     <li>Calls the <code>getInitializedLetterHints()</code> method to initialize
     *     the <code>letterHints</code> instance variable with default values (<code>-100</code>).</li>
     *     <li>Initializes the <code>previousGuesses</code> instance variable
     *     with an empty <code>ArrayList</code>.</li>
     * </ol>
     *
     * @param answer The word to be guessed in the current round.
     */
    public LetterJudge(){
        LetterJudge.increaseRoundCount();
        this.answer = answerWord.getName().toUpperCase();
        this.userInput = NONE_STRING;
        this.errorMessages = new ArrayList<>();
        this.letterHints = getInitializedLetterHints();
        this.previousGuesses = new ArrayList<>();
        this.previousGuessCount = 0;
        this.roundVerdictCode = ROUND_DEFAULT_CODE;
        this.roundScore = 0;
        if (roundCount == 0){
            FileIO.scoreBoardMaker("", false);
        }
    }
    // Merging Sorted Arraylists Method
    /**
     * <p><b>FUNCTIONALITY:</b> Merges two sorted <code>ArrayList</code> into a new
     * sorted <code>ArrayList</code> in <b>ASCENDING ALPHABETICAL ORDER</b>.</p>
     * <p><b>USED IN:</b> The two <code>ArrayList</code> are made of strings, which are the <b>ALL_CAPS</b> 5-letter
     * words of the <b>POSSIBLE_GUESSES</b> and the <b>POSSIBLE_ANSWERS</b> respectively.</p>
     *
     * <p><b>ASSUMPTIONS:</b> This method assumes that:
     * <ol>
     *  <li>The two <code>ArrayList</code> are made of <b>5-LETTER</b>, <b>ALL_CAPS STRINGS</b>.</li>
     *  <li>The two <code>ArrayList</code> are in <b>ASCENDING ALPHABETICAL ORDER</b>.</li>
     * </ol>
     * <b>Otherwise, the output of this method will be INCORRECT.</b>
     * <p><b>SAMPLE INPUT:</b> <code>sortedList1 = ["APPLE", "MODEL", "PEARS"], sortedList2 = ["BLACK", "DODGE"]</code></p>
     * <p><b>SAMPLE OUTPUT:</b> <code>mergedList = ["APPLE", "BLACK", "DODGE", "MODEL", "PEARS"]</code></p>
     *
     * <p><b>IMPLEMENTATION:</b> This method takes two sorted <code>ArrayList</code> as input and merges them into a new
     * sorted <code>ArrayList</code> using a merge algorithm similar to the merge step in the merge
     * sort algorithm. It iterates through both input lists simultaneously, comparing the elements
     * at the current indices and adding the smaller element to the merged list. After exhausting
     * one of the input lists, any remaining elements from the other list are appended to the merged
     * list.</p>
     *
     *
     * @param sortedList1 The first sorted <code>ArrayList</code> to be merged.
     * @param sortedList2 The second sorted <code>ArrayList</code> to be merged.
     * @return A new sorted <code>ArrayList</code> containing all elements from both input lists.
     */
    private static ArrayList<String> getMergedArrayList(ArrayList<String> sortedList1, ArrayList<String> sortedList2) {
        ArrayList<String> mergedList = new ArrayList<>();
        int index1 = 0;
        int index2 = 0;
        int n1 = sortedList1.size();
        int n2 = sortedList2.size();
       
        // Merge the two sorted lists
        while (index1 < n1 && index2 < n2) {
            String word1 = sortedList1.get(index1);
            String word2 = sortedList2.get(index2);
            boolean word1IsSmaller = (word1.compareTo(word2) < 0);
            boolean word1IsLarger = (word1.compareTo(word2) > 0);


            if (word1IsSmaller) {
                mergedList.add(word1);
                index1++;
            } else if (word1IsLarger) {
                mergedList.add(word2);
                index2++;
            } else {
                mergedList.add(word1);
                index1++;
                index2++;
            }
        }


        // Add remaining elements from sortedList1, if any
        while (index1 < n1) {
            String word1 = sortedList1.get(index1);
            mergedList.add(word1);
            index1++;
        }
       
        // Add remaining elements from sortedList2, if any
        while (index2 < n2) {
            String word2 = sortedList2.get(index2);
            mergedList.add(word2);
            index2++;
        }


        return mergedList;
    }
   
    // RoundCount Methods
    /**
     * Returns the current 1-based round count.
     * Each round contains at most 6 attempts.
     *
     * @return the current round count.
     */
    public static int getRoundCount() {
        return LetterJudge.roundCount;
    }
    /**
     * Update LetterJudge.roundCount by increasing it by 1
     */
    private static void increaseRoundCount(){
        LetterJudge.roundCount++;
    }
    // TODO: Dictionary Methods
    // TODO: Word Answer Methods
    // Answer Methods
    /**
     * Returns the current 5-letter ALL CAPS answer word.
     *
     * @return the answer string.
     */
    public String getAnswer() {
        return this.answer;
    }


    /**
     * Sets the answer to the provided string, converting it to ALL CAPS.
     *
     * @param answer the answer string to be set.
     * @return the current instance of <code>LetterJudge</code> with the updated answer.
     */
    public LetterJudge setAnswer(String answer) {
        this.answer = answer.toUpperCase();
        return this;
    }
    // UserInput Methods
    /**
     * Returns the user input.
     *
     * @return the user input string.
     */
    public String getUserInput() {
        return this.userInput;
    }


    /**
     * Sets the user input after validating it and updates other attributes accordingly.<p>
     * Converts the input to ALL CAPS, checks for errors, and updates
     * <code>this.errorMessages</code>, <code>this.letterHints</code>, <code>this.previousGuesses</code>,
     * <code>this.guessCount</code> and <code>this.roundVerdictCode</code> accordingly.
     *
     * @param userInput the user input string to be set.
     * @return the current instance of LetterJudge with the updated user input and attributes.
     */
    public LetterJudge setUserInput(String userInput) {
        // TODO: Validation by checking dictionary
        clearErrorMessages();
        userInput = userInput.toUpperCase();
        addErrorMessage(userInput);
        boolean isValid = (errorMessages.isEmpty());
        this.userInput = userInput;
        if (isValid){
            this.setLetterHints();
            this.addUserInputToPreviousGuesses();
            this.updatePreviousGuessCount();
            this.setRoundVerdictCode();
            this.setRoundScore();
        } else {
            this.setRoundVerdictCode();
        }
        return this;
    }
   
    // ErrorMessages Methods
    /**
     * Returns the error messages accumulated so far in <code>ArrayList</code> form.
     *
     * @return an arraylist with each error message (including <code>"\n"</code>) as an element.
     */
    public ArrayList<String> getErrorMessages(){
        return this.errorMessages;
    }
    /**
     * Returns the error messages accumulated so far in <code>string</code> form.
     *
     * @return a string containing the current error messages,
     * <b> SEPARATED BY but DO NOT END WITH <code>"\n"</code></b>
     */
    public String getErrorMessagesToString() {
        if (this.errorMessages.isEmpty()){
            return "";
        }
        String output = String.join("\n", this.errorMessages);
        return output;
    }


    /**
     * Adds an error message to <code>this.errorMessages</code>based on the given user input. <p>
     * Checks if the input contains only alphabets, has 5 letters,
     * and if it has been guessed previously.
     *
     * @param userInput the input provided by the user
     * @return the current instance of LetterJudge with updated error messages
     */
    private LetterJudge addErrorMessage(String userInput) {
        if (this.roundVerdictCode > 0){
            this.errorMessages.add("The round has ended!");
        }
        if (!getInitializedWordListToString().contains(userInput)){
            this.errorMessages.add(NOT_IN_LIST_ERROR_MESSAGE);
        }
        if (previousGuesses.contains(userInput)) {
            this.errorMessages.add(ALREADY_APPEARED_ERROR_MESSAGE);
        }
        return this;
    }
   
   
    /**
     * Clears all error messages.
     *
     * @return the current instance of <code>LetterJudge</code> with cleared error messages
     */
    private LetterJudge clearErrorMessages() {
        this.errorMessages = new ArrayList<>();
        return this;
    }
   
    public boolean getInputIsValid(){
        boolean hasUserInput = !userInput.equals(NONE_STRING);
        System.out.print(hasUserInput ? "" : "WARNING: there is no user input!\n");
        boolean inputHasNoErrorMessages = this.errorMessages.isEmpty();
        return (hasUserInput && inputHasNoErrorMessages);
    }
    // LetterHints Methods
    /**
     * Initializes the letter hints array with a default value <code>-100</code>.
     *
     * @return an array of integers initialized to the default value <code>-100</code>.
     */
    private static int[] getInitializedLetterHints() {
       
        int[] newLetterHints = new int[5];
        for (int i = 0; i < 5; i++) {
            newLetterHints[i] = LETTER_HINT_DEFAULT_VALUE;
        }
        return newLetterHints;
    }


    /**
     * Returns the current letter hints, such as <code>[0, 2, 1, 1, 0]</code><p>
     * (-100 for input has not been set, 0 for GREEN, 1 for YELLOW, 2 for GREY).
     *
     * @return (int[5]) The current letter hints
     */
    public int[] getLetterHints() {
        return this.letterHints;
    }


    /**
     * Converts the current letter hints to a string representation,<p>
     * Such as <code>"GREEN, GREY, YELLOW, YELLOW, GREEN"</code>.
     * @return a string representing the current letter hints, NO ENDLINE characters.
     */
    public String getLetterHintsToString() {
        String output = "";
        for (int letterHint : letterHints) {
            output += switch (letterHint) {
                case LETTER_HINT_GREEN_CODE -> ",GREEN";
                case LETTER_HINT_YELLOW_CODE -> ",YELLOW";
                case LETTER_HINT_GREY_CODE -> ",GREY";
                default -> ",None";
            };
        }
        output = output.substring(1);
        return output;
    }


    /**
     * Sets the letter hints based on the user input and the correct answer.
     * If there are error messages, the hints are reset.
     *
     * @return the current instance of <code>LetterJudge</code> with updated letter hints,
     * such as <code>[0, 2, 1, 1, 0]</code> <p>
     */
    public LetterJudge setLetterHints() {
        if (!this.errorMessages.isEmpty()) {
            letterHints = getInitializedLetterHints();
            return this;
        }
        for (int i = 0; i < 5; i++) {
            this.letterHints[i] = getLetterHintAtIndex(this.userInput, this.answer, i);
        }
        return this;
    }


    /**
     * Determines the hint for a specific letter in the user input.
     *
     * @param userInput the user's input string
     * @param answer the correct answer string
     * @param i the index of the letter to check
     * @return an integer code representing the hint (0 for GREEN, 1 for YELLOW, 2 for GREY)
     */
    private int getLetterHintAtIndex(String userInput, String answer, int i) {
        char inputLetter = userInput.charAt(i);
        char answerLetter = answer.charAt(i);
        if (inputLetter == answerLetter) {
            return LETTER_HINT_GREEN_CODE;
        } else if (answer.indexOf(inputLetter) >= 0) {
            return LETTER_HINT_YELLOW_CODE;
        } else {
            return LETTER_HINT_GREY_CODE;
        }
    }
    // PreviousGuesses Methods
    /**
     * Returns the list of previous guesses made by the user.
     *
     * @return an ArrayList of strings representing the previous guesses
     */
    public ArrayList<String> getPreviousGuesses() {
        return this.previousGuesses;
    }


    /**
     * <p>Returns a comma-separated string representation of the previous guesses (Arraylist of strings).
     * The string includes all previous guesses (including the final correct/wrong guess),
     * and if the number of previous guesses is less than the maximum allowed number of guesses (6),
     * it pads the remaining positions with the string <code>"None"</code>.</p>
     *
     * <p>NO endline characters are included.</p>
     * <p>The string is not sorted by alphabetical order, but rather by the order which the user guesses.</p>
     * <p>This method calls on the attribute of the object, so only call this after the CURRENT ROUND IS FINISHED.</p>
     *
     * <p><b>SAMPLE INPUT:</b> <code>this.previousGuesses = ["APPLE", "ZEBRA", "MANGO"]</code> (automatically passed)</p>
     * <p><b>SAMPLE OUTPUT:</b> <code>"APPLE,ZEBRA,MANGO,None,None,None"</code></p>
     *
     * @return A comma-separated string representation of the previous guesses, with any remaining
     *         positions padded with "None" if the number of previous guesses is less than the maximum
     *         allowed number of guesses.
     */
    public String getPreviousGuessesToString() {
        String output = "";
        int n = this.previousGuesses.size();
        for (int i = 0; i < n; i++){
            String previousGuess = this.previousGuesses.get(i);
            output += (TO_STRING_DELIMITER + previousGuess);
        }
        for (int i = n; i < MAX_GUESS_COUNT; i++){
            output += (TO_STRING_DELIMITER + NONE_STRING);
        }
        output = output.substring(1);
        return output;
    }


    /**
     * Adds the user input to the list of previous guesses if there are no error messages.
     *
     * @return the current instance of LetterJudge with the updated list of previous guesses
     */
    private LetterJudge addUserInputToPreviousGuesses() {
        if (!this.errorMessages.isEmpty()) {
            return this;
        }
        if (!userInput.equals(NONE_STRING)) {
            this.previousGuesses.add(userInput);
        }
        return this;
    }


    // PreviousGuessCount Methods
    /**
     * Returns the number of guesses made PREVIOUSLY by the user.
     *
     * @return an integer representing the current 0-based guess count
     */
    public int getPreviousGuessCount() {
        return this.previousGuessCount;
    }


    /**
     * Updates the guess count by incrementing it if there are no errors. Otherwise do nothing.
     *
     * @return the current instance of LetterJudge with the updated 0-based guess count
     */
    private LetterJudge updatePreviousGuessCount() {
        if (!this.errorMessages.isEmpty()) {
            return this;
        }
        this.previousGuessCount++;
        return this;
    }
    // RoundVerdictCode Methods
   
    /**
     * Returns the current isContinueCode indicating the state of the game. <p>
     * (0 : continue playing, 1 : User guessed correctly, 2 : Run out of guesses) <p>
     * (-1 is undecided, which means setRoundVerdictCode has not been run.)
     *
     * @return an integer representing the current roundVerdictCode
     */
    public int getRoundVerdictCode() {
        return this.roundVerdictCode;
    }


    /**
     * Sets the isContinueCode based on the current state of the game.
     * The code is set to indicate whether the game continues, the guess is correct,
     * or the maximum number of guesses has been reached.
     */
    private LetterJudge setRoundVerdictCode() {
        boolean guessCorrect = (userInput.equals(answer));
        boolean maxGuessReached = (previousGuessCount >= MAX_GUESS_COUNT);
        if (guessCorrect) {
            this.roundVerdictCode = ROUND_CORRECT_GUESS_CODE;
            FileIO.scoreBoardMaker(this.toString(), !(LetterJudge.getRoundCount() == 1));
        } else if (maxGuessReached) {
            this.roundVerdictCode = ROUND_MAXIMUM_GUESS_REACHED_CODE;
            FileIO.scoreBoardMaker(this.toString(), !(LetterJudge.getRoundCount() == 1));
        } else {
            this.roundVerdictCode = ROUND_IS_CONTINUE_CODE;
        }
        return this;
    }


    /**
     * Converts the current roundVerdictCode to a string representation.
     *
     * @return a string representing the current <code>roundVerdictCode, no endline characters</code>
     *
     * <p>Possible outputs:</p>
     *
     * <ul>
     *     <li>If the game continues (<code>roundVerdictCode = 0</code>), the output will be:
     *         <code>"The game continues."</code>
     *     </li>
     *     <li>If the user guessed the correct answer (<code>roundVerdictCode = 1</code>), the output will be:
     *         <code>"Congratulations! It takes [guessCount] out of 6 tries".</code><p>
     *         For example, if the user took 4 guesses to get the correct answer, the output would be:
     *         <code>"Congratulations! It takes 4 out of 6 tries."</code>
     *     </li>
     *     <li>If the user has reached the maximum number of guesses without guessing the correct answer
     *         (<code>roundVerdictCode = 2</code>), the output will be:
     *         <code>"Unfortunately you cannot get this one. The answer is [answer]."</code>. <p>
     *         The answer is a 5-letter word in ALL CAPS.<p>
     *         For example, if the correct answer was "APPLE", the output would be:
     *         <code>"Unfortunately you cannot get this one. The answer is APPLE."</code>
     *     </li>
     * </ul>
     */
    public String getRoundVerdictCodeToOutputString() {
        String output = switch (this.getRoundVerdictCode()) {
            case ROUND_CORRECT_GUESS_CODE -> String.format(WORD_GUESSED_MESSAGE_FORMAT, this.getPreviousGuessCount(), MAX_GUESS_COUNT);
            case ROUND_MAXIMUM_GUESS_REACHED_CODE -> String.format(MAX_GUESSES_REACHED_MESSAGE_FORMAT, this.getAnswer());
            default -> throw new AssertionError();
        };
        return output;        
    }


    public int getRoundScore(){
        return roundScore;
    }
   
    public LetterJudge setRoundScore(){
        boolean inputIsInvalid = !this.getInputIsValid();
        boolean roundNotEnded = (this.getRoundVerdictCode() == ROUND_IS_CONTINUE_CODE);
        if (inputIsInvalid || roundNotEnded){
            return this;
        }
        int guessCount = getPreviousGuessCount();
        if ((guessCount == MAX_GUESS_COUNT) && (!userInput.equals(answer))){
            guessCount = -1;
        }
        int score = POINT_SYSTEM.getOrDefault(guessCount, 0);
        this.roundScore = score;
        LetterJudge.addTotalScore(score);
        return this;
    }


    public static int getTotalScore(){
        return LetterJudge.totalScore;
    }
    public static void resetTotalScore(){
        LetterJudge.totalScore = 0;
    }
    public static void addTotalScore(int RoundScore){
        LetterJudge.totalScore += RoundScore;
    }
    public String getAnswerDefinitionsToString(){
        String[] definitionsInArray = answerDefinitions.split("&");
        int n = definitionsInArray.length;
        for (int i = 0; i < n; i++){
            definitionsInArray[i] = "Definition " + definitionsInArray[i];
        }
        return String.join("\n", definitionsInArray);
    }
    public String getAnswerExamplesToString(){
        String[] examplesInArray = answerExamples.split("&");
        int n = examplesInArray.length;
        for (int i = 0; i < n; i++){
            examplesInArray[i] = "Example " + examplesInArray[i];
        }
        return String.join("\n", examplesInArray);
    }
    public String getAnswerDefinitionsWithExamplesToString(){
        String[] definitionsInArray = answerDefinitions.split("&");
        String[] examplesInArray = answerExamples.split("&");
        ArrayList<String> outputLines = new ArrayList<>();
        int n = definitionsInArray.length;
        for (int i = 0; i < n; i++){
            String definition = definitionsInArray[i];
            String example = examplesInArray[i];
            outputLines.add("Definition " + definition);
            outputLines.add("Example " + example);
        }
        return String.join("\n", outputLines);
    }
    /**
     * Returns a string representation of the current round's state, including the round count, answer,
     * previous guess count, and the previous guesses made.
     *
     * The single line of the returned string has NO trailing endline character and is separated by commas.
     * Invalid inputs from the user are not included.
     * If the user has guessed the word before all 6 attempts are used up, remaining guesses will be filled up with "None".
     * See SAMPLE OUTPUT 1 for further explanation.
     *
     * <p><b>SAMPLE INPUT 1:</b>
     * <ul>
     *     <li><code>LetterJudge.roundCount = 3</code></li>
     *     <li><code>this.answer = "ROBOT"</code></li>
     *     <li><code>this.previousGuessCount = 4</code></li>
     *     <li><code>roundVerdictCode = 1</code></li>
     *     <li><code>this.previousGuesses = ["ARISE", "ZEBRA", "MOTOR", "ROBOT"]</code></li>
     * </ul>
     * </p>
     * <p><b>SAMPLE OUTPUT 1:</b> <code>"3,ROBOT,4,ARISE,ZEBRA,MOTOR,ROBOT,None,None"</code></p>
     * <p><b>Explanation:</b> The output string represents the following:
     * <ul>
     *     <li><code>3</code>: The round count (3rd round, i.e. this is the third word that the user has tried to guess)</li>
     *     <li><code>ROBOT</code>: The answer for this round</li>
     *     <li><code>4</code>: The number of previous guesses made (4 guesses)</li>
     *     <li><code>ARISE,ZEBRA,MOTOR,ROBOT</code>: The previous guesses made.
     *     The last string is the answer, which shows that the user has successfully guessed the word.
     *     If the user has not, the code would have been <code>-1</code>.
     *     </li>
     *     <li><code>None,None</code>: Padding for the remaining positions since the maximum number of guesses is 6</li>
     * </ul></p>
     *
     * <p><b>SAMPLE INPUT 2:</b>
     * <ul>
     *     <li><code>LetterJudge.roundCount = 5</code></li>
     *     <li><code>this.answer = "MONEY"</code></li>
     *     <li><code>this.previousGuessCount = 6</code></li>
     *     <li><code>roundVerdictCode = 2</code></li>
     *     <li><code>this.previousGuesses = ["APPLE", "BRAVE", "CARRY", "DARTS", "ERUPT", "FARMS"]</code></li>
     * </ul>
     * </p>
     * <p><b>SAMPLE OUTPUT 2:</b> <code>"5,MONEY,-1,APPLE,BRAVE,CARRY,DARTS,ERUPT,FARMS"</code></p>
     * <p><b>Explanation:</b> The output string represents the following:
     * <ul>
     *     <li><code>5</code>: The round count (5th round)</li>
     *     <li><code>MONEY</code>: The answer for this round</li>
     *     <li><code>-1</code>: Indicates that the user has run out of guesses (<code>roundVerdictCode == 2</code>)</li>
     *     <li><code>APPLE,BRAVE,CARRY,DARTS,ERUPT,FARMS</code>: The previous guesses made.
     *     Notice that the answer did not appear in the 6 guesses</li>
     * </ul></p>
     *
     * @return A string representation of the current round's state, formatted as follows:
     *         <code>"roundCount,answer,previousGuessCount,previousGuess1,previousGuess2,...,previousGuessN\n"</code>
     *         (<code>N == letterJudge.MAX_GUESS_COUNT (6)</code>)
     *         If <code>roundVerdictCode == 2</code> (run out of guesses), the previousGuessCount is set to -1.
     *         If <code>roundVerdictCode == 0</code> (the round is still ongoing), an error message is returned.
     */
    @Override
    public String toString(){
        // this.getRoundVerdictCode() : (0 means continue playing, 1 means user guessed correctly, 2 means run out of guesses)
        String roundCountString = String.valueOf(LetterJudge.getRoundCount());
        String previousGuessCountString = String.valueOf(
            (this.getRoundVerdictCode() == 2) ? -1 : this.getPreviousGuessCount()
        );
        String roundCountScoreString = String.valueOf(this.getRoundScore());
        String totalScoreString = String.valueOf(LetterJudge.getTotalScore());
        String output = String.join(TO_STRING_DELIMITER,
            roundCountString, answer, previousGuessCountString, roundCountScoreString, totalScoreString
        );
        return output;
    }
    public String getStringForTesting(){
        String output = "\n\n";
        if (this.getRoundVerdictCode() <= 0){
            output += "WARNING: The round has not ended!\n";
        }
        String format = """
                Current Attributes:
                LetterJudge.getRoundCount() = %d
                this.getAnswer() = "%s"
                this.getUserInput() = "%s"
                this.getErrorMessagesToString() = "%s"
                this.getInputIsValid() = %b
                this.getLetterHints() (as an int[]) = %s
                (%d for input has not been set, %d for GREEN, %d for YELLOW, %d for GREY.)
                this.getLetterHintsToString() = "%s"
                this.getPreviousGuessesToString() = "%s"
                this.getPreviousGuessCount() (for this round) = %d
                this.getRoundVerdictCode() = %d
                (%d for user has not input yet, %d for round continues, %d for user guessed correctly, %d for ran out of attempts.)
                this.toString() = "%s"
                this.roundScore = %d
                LetterJudge.totalScore = %d




                NOTE: When the user inputs are invalid, letterHints (and its toString) will stay the same as the last valid word.


                """;
        output += String.format(format,
            LetterJudge.getRoundCount(),
            this.getAnswer(),
            this.getUserInput(),
            this.getErrorMessagesToString(),
            this.getInputIsValid(),
            Arrays.toString(this.getLetterHints()),
            LETTER_HINT_DEFAULT_VALUE, LETTER_HINT_GREEN_CODE, LETTER_HINT_YELLOW_CODE, LETTER_HINT_GREY_CODE,
            this.getLetterHintsToString(),
            this.getPreviousGuessesToString(),
            this.getPreviousGuessCount(),
            this.getRoundVerdictCode(),
            ROUND_DEFAULT_CODE,
            ROUND_IS_CONTINUE_CODE, ROUND_CORRECT_GUESS_CODE, ROUND_MAXIMUM_GUESS_REACHED_CODE,
            this.toString(),
            this.getRoundScore(),
            LetterJudge.getTotalScore()
        );
        return output;
    }
    public static void MergeArrayTest(){
        ArrayList<String> list1 = new ArrayList<>(Arrays.asList("APPLE", "MANGO", "PANDA"));
        ArrayList<String> list2 = new ArrayList<>(Arrays.asList("BANDS", "KIWIS", "LANDS", "SWEET"));
        System.out.println(getMergedArrayList(list1, list2).toString());
    }
    public static void main(String[] args) {
        try (Scanner reader = new Scanner(System.in)) {
            while (true) {
                playRound(reader);
            }
        }
    }
    private static void playRound(Scanner reader) {
        LetterJudge roundLetterJudge = new LetterJudge();
        // roundLetterJudge is counted due to initialization on last line.
        System.out.println("Round " + LetterJudge.getRoundCount());
        do {
            // Round 1 <- 0 previous guesses <- guessCount is 0
            // TODO: Test the code with this line: System.out.print("Previous Guess: " + roundLetterJudge.getStringForTesting());
            System.out.printf("Enter guess %d : ", roundLetterJudge.getPreviousGuessCount() + 1);
            String userInput = reader.nextLine();
            roundLetterJudge.setUserInput(userInput);
            // TODO: Test the code with this line: System.out.print("After the Guess: " + roundLetterJudge.getStringForTesting());
            boolean inputIsValid = (roundLetterJudge.getErrorMessagesToString().isEmpty());
            String displayMessage = (
                inputIsValid ?
                roundLetterJudge.getLetterHintsToString() :
                roundLetterJudge.getErrorMessagesToString()
            ); // print hints if word valid, otherwise print the error messages
            // getErrorMessagesToString does not need println since the trailing \n is already there
            System.out.println(displayMessage);
        } while (roundLetterJudge.getRoundVerdictCode() == 0);
        // 0: "The game continues". Refer to getRoundVerdictCode for more details
        System.out.println("getRoundVerdictCodeToOutputString() : \n" + roundLetterJudge.getRoundVerdictCodeToOutputString()); // Guessed the word or not
        System.out.println("The toString() method : \n" + roundLetterJudge.toString());
        System.out.println("getAnswerDefinitionsToString() : \n" + roundLetterJudge.getAnswerDefinitionsToString());
        System.out.println("getAnswerExamplesToString() : \n" + roundLetterJudge.getAnswerExamplesToString());
        System.out.println("getAnswerDefinitionWithExamplesToString() : \n" + roundLetterJudge.getAnswerDefinitionsWithExamplesToString());
        FileIO.scoreBoardMaker(roundLetterJudge.toString(), true);
    }  
}



